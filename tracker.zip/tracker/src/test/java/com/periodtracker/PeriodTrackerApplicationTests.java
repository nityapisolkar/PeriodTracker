package com.periodtracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PeriodTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
